import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setBackendStatus, setError, logMessage } from './store';
import HealthCheck from './components/HealthCheck';
import ZillowScraper from './components/ZillowScraper';
import CrexiScraper from './components/CrexiScraper';
import Logs from './components/Logs';

const App = () => {
    const dispatch = useDispatch();
    const backendStatus = useSelector((state) => state.backendStatus);

    useEffect(() => {
        const checkBackendHealth = async () => {
            try {
                const response = await fetch('/api/health');
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();
                dispatch(setBackendStatus(data.status));
                dispatch(logMessage('Backend health check passed'));
            } catch (error) {
                dispatch(setBackendStatus('error'));
                dispatch(setError('Error connecting to backend'));
                dispatch(logMessage('Backend health check failed: ' + error.message));
            }
        };

        checkBackendHealth();
        const interval = setInterval(checkBackendHealth, 5000);
        return () => clearInterval(interval);
    }, [dispatch]);

    return (
        <div>
            <h1>Real Estate Scraper</h1>
            <p>Backend status: {backendStatus}</p>
            <ZillowScraper />
            <CrexiScraper />
            <Logs />
            <HealthCheck />
        </div>
    );
};

export default App;
