import { configureStore, createSlice } from '@reduxjs/toolkit';

// Initial state
const initialState = {
    backendStatus: 'unknown',
    logs: [],
    error: null
};

// Create slice
const slice = createSlice({
    name: 'app',
    initialState,
    reducers: {
        setBackendStatus: (state, action) => {
            state.backendStatus = action.payload;
        },
        logMessage: (state, action) => {
            state.logs.push(action.payload);
        },
        setError: (state, action) => {
            state.error = action.payload;
        }
    }
});

// Export actions
export const { setBackendStatus, logMessage, setError } = slice.actions;

// Configure store
const store = configureStore({
    reducer: slice.reducer
});

export default store;
