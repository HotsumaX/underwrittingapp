import React, { useState } from 'react';
import axios from 'axios';

const ZillowScraper = () => {
    const [url, setUrl] = useState('');
    const [result, setResult] = useState(null);

    const fetchZillowData = async () => {
        try {
            const response = await axios.get(`http://localhost:5000/api/scrape_zillow?url=${url}`);
            setResult(response.data);
        } catch (error) {
            setResult({ error: error.message });
        }
    };

    return (
        <div>
            <h2>Scrape Zillow</h2>
            <input type="text" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Enter Zillow URL" />
            <button onClick={fetchZillowData}>Fetch Zillow Data</button>
            {result && <pre>{JSON.stringify(result, null, 2)}</pre>}
        </div>
    );
};

export default ZillowScraper;
