from flask import Flask, request, jsonify, send_file
from scrape_zillow_with_selenium import scrape_zillow_listing
import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import time

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy"}), 200

@app.route('/api/scrape_zillow', methods=['GET'])
def scrape_zillow():
    url = request.args.get('url')
    if not url:
        return jsonify({"error": "URL parameter is required"}), 400
    
    try:
        data = scrape_zillow_listing(url)
        return jsonify(data)
    except Exception as e:
        logging.error(f"Error scraping Zillow listing: {e}")
        return jsonify({"error": f"Error scraping Zillow listing: {e}"}), 500

@app.route('/api/fetch_html', methods=['GET'])
def fetch_html():
    url = request.args.get('url')
    if not url:
        return jsonify({"error": "URL parameter is required"}), 400
    
    try:
        html_content = fetch_html_content(url)
        with open("zillow_listing.html", "w") as file:
            file.write(html_content)
        return send_file("zillow_listing.html", as_attachment=True)
    except Exception as e:
        logging.error(f"Error fetching HTML content: {e}")
        return jsonify({"error": f"Error fetching HTML content: {e}"}), 500

def fetch_html_content(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)
    
    driver.get(url)
    time.sleep(3)  # Wait for the page to fully load
    html_content = driver.page_source
    
    driver.quit()
    
    return html_content

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
